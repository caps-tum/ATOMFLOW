-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
-- Tool Version Limit: 2024.11
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- 
-- ==============================================================
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity atomflow_controller_control_s_axi is
generic (
    C_S_AXI_ADDR_WIDTH    : INTEGER := 8;
    C_S_AXI_DATA_WIDTH    : INTEGER := 32);
port (
    ACLK                  :in   STD_LOGIC;
    ARESET                :in   STD_LOGIC;
    ACLK_EN               :in   STD_LOGIC;
    AWADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    AWVALID               :in   STD_LOGIC;
    AWREADY               :out  STD_LOGIC;
    WDATA                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    WSTRB                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH/8-1 downto 0);
    WVALID                :in   STD_LOGIC;
    WREADY                :out  STD_LOGIC;
    BRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    BVALID                :out  STD_LOGIC;
    BREADY                :in   STD_LOGIC;
    ARADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    ARVALID               :in   STD_LOGIC;
    ARREADY               :out  STD_LOGIC;
    RDATA                 :out  STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    RRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    RVALID                :out  STD_LOGIC;
    RREADY                :in   STD_LOGIC;
    interrupt             :out  STD_LOGIC;
    mode                  :out  STD_LOGIC_VECTOR(7 downto 0);
    emission_threshold    :out  STD_LOGIC_VECTOR(31 downto 0);
    atomLocationsSize     :out  STD_LOGIC_VECTOR(31 downto 0);
    projShape0            :out  STD_LOGIC_VECTOR(31 downto 0);
    projShape1            :out  STD_LOGIC_VECTOR(31 downto 0);
    atomLocations         :out  STD_LOGIC_VECTOR(63 downto 0);
    psfSupersample        :out  STD_LOGIC_VECTOR(31 downto 0);
    imageProjectionSize   :out  STD_LOGIC_VECTOR(31 downto 0);
    imageProjs_local      :out  STD_LOGIC_VECTOR(63 downto 0);
    imageProjs            :out  STD_LOGIC_VECTOR(63 downto 0);
    imageProjs_local_size :out  STD_LOGIC_VECTOR(63 downto 0);
    fullImage             :out  STD_LOGIC_VECTOR(63 downto 0);
    fullImage_rows        :out  STD_LOGIC_VECTOR(31 downto 0);
    fullImage_cols        :out  STD_LOGIC_VECTOR(31 downto 0);
    emissions             :out  STD_LOGIC_VECTOR(63 downto 0);
    grid_rows             :out  STD_LOGIC_VECTOR(31 downto 0);
    grid_cols             :out  STD_LOGIC_VECTOR(31 downto 0);
    targetGeometry_mem    :out  STD_LOGIC_VECTOR(63 downto 0);
    compZoneRowStart      :out  STD_LOGIC_VECTOR(31 downto 0);
    compZoneRowEnd        :out  STD_LOGIC_VECTOR(31 downto 0);
    compZoneColStart      :out  STD_LOGIC_VECTOR(31 downto 0);
    compZoneColEnd        :out  STD_LOGIC_VECTOR(31 downto 0);
    moveCount             :in   STD_LOGIC_VECTOR(31 downto 0);
    moveCount_ap_vld      :in   STD_LOGIC;
    ap_start              :out  STD_LOGIC;
    ap_done               :in   STD_LOGIC;
    ap_ready              :in   STD_LOGIC;
    ap_idle               :in   STD_LOGIC
);
end entity atomflow_controller_control_s_axi;

-- ------------------------Address Info-------------------
-- Protocol Used: ap_ctrl_hs
--
-- 0x00 : Control signals
--        bit 0  - ap_start (Read/Write/COH)
--        bit 1  - ap_done (Read/COR)
--        bit 2  - ap_idle (Read)
--        bit 3  - ap_ready (Read/COR)
--        bit 7  - auto_restart (Read/Write)
--        bit 9  - interrupt (Read)
--        others - reserved
-- 0x04 : Global Interrupt Enable Register
--        bit 0  - Global Interrupt Enable (Read/Write)
--        others - reserved
-- 0x08 : IP Interrupt Enable Register (Read/Write)
--        bit 0 - enable ap_done interrupt (Read/Write)
--        bit 1 - enable ap_ready interrupt (Read/Write)
--        others - reserved
-- 0x0c : IP Interrupt Status Register (Read/TOW)
--        bit 0 - ap_done (Read/TOW)
--        bit 1 - ap_ready (Read/TOW)
--        others - reserved
-- 0x10 : Data signal of mode
--        bit 7~0 - mode[7:0] (Read/Write)
--        others  - reserved
-- 0x14 : reserved
-- 0x18 : Data signal of emission_threshold
--        bit 31~0 - emission_threshold[31:0] (Read/Write)
-- 0x1c : reserved
-- 0x20 : Data signal of atomLocationsSize
--        bit 31~0 - atomLocationsSize[31:0] (Read/Write)
-- 0x24 : reserved
-- 0x28 : Data signal of projShape0
--        bit 31~0 - projShape0[31:0] (Read/Write)
-- 0x2c : reserved
-- 0x30 : Data signal of projShape1
--        bit 31~0 - projShape1[31:0] (Read/Write)
-- 0x34 : reserved
-- 0x38 : Data signal of atomLocations
--        bit 31~0 - atomLocations[31:0] (Read/Write)
-- 0x3c : Data signal of atomLocations
--        bit 31~0 - atomLocations[63:32] (Read/Write)
-- 0x40 : reserved
-- 0x44 : Data signal of psfSupersample
--        bit 31~0 - psfSupersample[31:0] (Read/Write)
-- 0x48 : reserved
-- 0x4c : Data signal of imageProjectionSize
--        bit 31~0 - imageProjectionSize[31:0] (Read/Write)
-- 0x50 : reserved
-- 0x54 : Data signal of imageProjs_local
--        bit 31~0 - imageProjs_local[31:0] (Read/Write)
-- 0x58 : Data signal of imageProjs_local
--        bit 31~0 - imageProjs_local[63:32] (Read/Write)
-- 0x5c : reserved
-- 0x60 : Data signal of imageProjs
--        bit 31~0 - imageProjs[31:0] (Read/Write)
-- 0x64 : Data signal of imageProjs
--        bit 31~0 - imageProjs[63:32] (Read/Write)
-- 0x68 : reserved
-- 0x6c : Data signal of imageProjs_local_size
--        bit 31~0 - imageProjs_local_size[31:0] (Read/Write)
-- 0x70 : Data signal of imageProjs_local_size
--        bit 31~0 - imageProjs_local_size[63:32] (Read/Write)
-- 0x74 : reserved
-- 0x78 : Data signal of fullImage
--        bit 31~0 - fullImage[31:0] (Read/Write)
-- 0x7c : Data signal of fullImage
--        bit 31~0 - fullImage[63:32] (Read/Write)
-- 0x80 : reserved
-- 0x84 : Data signal of fullImage_rows
--        bit 31~0 - fullImage_rows[31:0] (Read/Write)
-- 0x88 : reserved
-- 0x8c : Data signal of fullImage_cols
--        bit 31~0 - fullImage_cols[31:0] (Read/Write)
-- 0x90 : reserved
-- 0x94 : Data signal of emissions
--        bit 31~0 - emissions[31:0] (Read/Write)
-- 0x98 : Data signal of emissions
--        bit 31~0 - emissions[63:32] (Read/Write)
-- 0x9c : reserved
-- 0xa0 : Data signal of grid_rows
--        bit 31~0 - grid_rows[31:0] (Read/Write)
-- 0xa4 : reserved
-- 0xa8 : Data signal of grid_cols
--        bit 31~0 - grid_cols[31:0] (Read/Write)
-- 0xac : reserved
-- 0xb0 : Data signal of targetGeometry_mem
--        bit 31~0 - targetGeometry_mem[31:0] (Read/Write)
-- 0xb4 : Data signal of targetGeometry_mem
--        bit 31~0 - targetGeometry_mem[63:32] (Read/Write)
-- 0xb8 : reserved
-- 0xbc : Data signal of compZoneRowStart
--        bit 31~0 - compZoneRowStart[31:0] (Read/Write)
-- 0xc0 : reserved
-- 0xc4 : Data signal of compZoneRowEnd
--        bit 31~0 - compZoneRowEnd[31:0] (Read/Write)
-- 0xc8 : reserved
-- 0xcc : Data signal of compZoneColStart
--        bit 31~0 - compZoneColStart[31:0] (Read/Write)
-- 0xd0 : reserved
-- 0xd4 : Data signal of compZoneColEnd
--        bit 31~0 - compZoneColEnd[31:0] (Read/Write)
-- 0xd8 : reserved
-- 0xdc : Data signal of moveCount
--        bit 31~0 - moveCount[31:0] (Read)
-- 0xe0 : Control signal of moveCount
--        bit 0  - moveCount_ap_vld (Read/COR)
--        others - reserved
-- (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

architecture behave of atomflow_controller_control_s_axi is
    type states is (wridle, wrdata, wrresp, wrreset, rdidle, rddata, rdreset);  -- read and write fsm states
    signal wstate  : states := wrreset;
    signal rstate  : states := rdreset;
    signal wnext, rnext: states;
    constant ADDR_AP_CTRL                      : INTEGER := 16#00#;
    constant ADDR_GIE                          : INTEGER := 16#04#;
    constant ADDR_IER                          : INTEGER := 16#08#;
    constant ADDR_ISR                          : INTEGER := 16#0c#;
    constant ADDR_MODE_DATA_0                  : INTEGER := 16#10#;
    constant ADDR_MODE_CTRL                    : INTEGER := 16#14#;
    constant ADDR_EMISSION_THRESHOLD_DATA_0    : INTEGER := 16#18#;
    constant ADDR_EMISSION_THRESHOLD_CTRL      : INTEGER := 16#1c#;
    constant ADDR_ATOMLOCATIONSSIZE_DATA_0     : INTEGER := 16#20#;
    constant ADDR_ATOMLOCATIONSSIZE_CTRL       : INTEGER := 16#24#;
    constant ADDR_PROJSHAPE0_DATA_0            : INTEGER := 16#28#;
    constant ADDR_PROJSHAPE0_CTRL              : INTEGER := 16#2c#;
    constant ADDR_PROJSHAPE1_DATA_0            : INTEGER := 16#30#;
    constant ADDR_PROJSHAPE1_CTRL              : INTEGER := 16#34#;
    constant ADDR_ATOMLOCATIONS_DATA_0         : INTEGER := 16#38#;
    constant ADDR_ATOMLOCATIONS_DATA_1         : INTEGER := 16#3c#;
    constant ADDR_ATOMLOCATIONS_CTRL           : INTEGER := 16#40#;
    constant ADDR_PSFSUPERSAMPLE_DATA_0        : INTEGER := 16#44#;
    constant ADDR_PSFSUPERSAMPLE_CTRL          : INTEGER := 16#48#;
    constant ADDR_IMAGEPROJECTIONSIZE_DATA_0   : INTEGER := 16#4c#;
    constant ADDR_IMAGEPROJECTIONSIZE_CTRL     : INTEGER := 16#50#;
    constant ADDR_IMAGEPROJS_LOCAL_DATA_0      : INTEGER := 16#54#;
    constant ADDR_IMAGEPROJS_LOCAL_DATA_1      : INTEGER := 16#58#;
    constant ADDR_IMAGEPROJS_LOCAL_CTRL        : INTEGER := 16#5c#;
    constant ADDR_IMAGEPROJS_DATA_0            : INTEGER := 16#60#;
    constant ADDR_IMAGEPROJS_DATA_1            : INTEGER := 16#64#;
    constant ADDR_IMAGEPROJS_CTRL              : INTEGER := 16#68#;
    constant ADDR_IMAGEPROJS_LOCAL_SIZE_DATA_0 : INTEGER := 16#6c#;
    constant ADDR_IMAGEPROJS_LOCAL_SIZE_DATA_1 : INTEGER := 16#70#;
    constant ADDR_IMAGEPROJS_LOCAL_SIZE_CTRL   : INTEGER := 16#74#;
    constant ADDR_FULLIMAGE_DATA_0             : INTEGER := 16#78#;
    constant ADDR_FULLIMAGE_DATA_1             : INTEGER := 16#7c#;
    constant ADDR_FULLIMAGE_CTRL               : INTEGER := 16#80#;
    constant ADDR_FULLIMAGE_ROWS_DATA_0        : INTEGER := 16#84#;
    constant ADDR_FULLIMAGE_ROWS_CTRL          : INTEGER := 16#88#;
    constant ADDR_FULLIMAGE_COLS_DATA_0        : INTEGER := 16#8c#;
    constant ADDR_FULLIMAGE_COLS_CTRL          : INTEGER := 16#90#;
    constant ADDR_EMISSIONS_DATA_0             : INTEGER := 16#94#;
    constant ADDR_EMISSIONS_DATA_1             : INTEGER := 16#98#;
    constant ADDR_EMISSIONS_CTRL               : INTEGER := 16#9c#;
    constant ADDR_GRID_ROWS_DATA_0             : INTEGER := 16#a0#;
    constant ADDR_GRID_ROWS_CTRL               : INTEGER := 16#a4#;
    constant ADDR_GRID_COLS_DATA_0             : INTEGER := 16#a8#;
    constant ADDR_GRID_COLS_CTRL               : INTEGER := 16#ac#;
    constant ADDR_TARGETGEOMETRY_MEM_DATA_0    : INTEGER := 16#b0#;
    constant ADDR_TARGETGEOMETRY_MEM_DATA_1    : INTEGER := 16#b4#;
    constant ADDR_TARGETGEOMETRY_MEM_CTRL      : INTEGER := 16#b8#;
    constant ADDR_COMPZONEROWSTART_DATA_0      : INTEGER := 16#bc#;
    constant ADDR_COMPZONEROWSTART_CTRL        : INTEGER := 16#c0#;
    constant ADDR_COMPZONEROWEND_DATA_0        : INTEGER := 16#c4#;
    constant ADDR_COMPZONEROWEND_CTRL          : INTEGER := 16#c8#;
    constant ADDR_COMPZONECOLSTART_DATA_0      : INTEGER := 16#cc#;
    constant ADDR_COMPZONECOLSTART_CTRL        : INTEGER := 16#d0#;
    constant ADDR_COMPZONECOLEND_DATA_0        : INTEGER := 16#d4#;
    constant ADDR_COMPZONECOLEND_CTRL          : INTEGER := 16#d8#;
    constant ADDR_MOVECOUNT_DATA_0             : INTEGER := 16#dc#;
    constant ADDR_MOVECOUNT_CTRL               : INTEGER := 16#e0#;
    constant ADDR_BITS         : INTEGER := 8;

    signal waddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal wmask               : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal aw_hs               : STD_LOGIC;
    signal w_hs                : STD_LOGIC;
    signal rdata_data          : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal ar_hs               : STD_LOGIC;
    signal raddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal AWREADY_t           : STD_LOGIC;
    signal WREADY_t            : STD_LOGIC;
    signal ARREADY_t           : STD_LOGIC;
    signal RVALID_t            : STD_LOGIC;
    -- internal registers
    signal int_ap_idle         : STD_LOGIC := '0';
    signal int_ap_ready        : STD_LOGIC := '0';
    signal task_ap_ready       : STD_LOGIC;
    signal int_ap_done         : STD_LOGIC := '0';
    signal task_ap_done        : STD_LOGIC;
    signal int_task_ap_done    : STD_LOGIC := '0';
    signal int_ap_start        : STD_LOGIC := '0';
    signal int_interrupt       : STD_LOGIC := '0';
    signal int_auto_restart    : STD_LOGIC := '0';
    signal auto_restart_status : STD_LOGIC := '0';
    signal auto_restart_done   : STD_LOGIC;
    signal int_gie             : STD_LOGIC := '0';
    signal int_ier             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_isr             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_mode            : UNSIGNED(7 downto 0) := (others => '0');
    signal int_emission_threshold : UNSIGNED(31 downto 0) := (others => '0');
    signal int_atomLocationsSize : UNSIGNED(31 downto 0) := (others => '0');
    signal int_projShape0      : UNSIGNED(31 downto 0) := (others => '0');
    signal int_projShape1      : UNSIGNED(31 downto 0) := (others => '0');
    signal int_atomLocations   : UNSIGNED(63 downto 0) := (others => '0');
    signal int_psfSupersample  : UNSIGNED(31 downto 0) := (others => '0');
    signal int_imageProjectionSize : UNSIGNED(31 downto 0) := (others => '0');
    signal int_imageProjs_local : UNSIGNED(63 downto 0) := (others => '0');
    signal int_imageProjs      : UNSIGNED(63 downto 0) := (others => '0');
    signal int_imageProjs_local_size : UNSIGNED(63 downto 0) := (others => '0');
    signal int_fullImage       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_fullImage_rows  : UNSIGNED(31 downto 0) := (others => '0');
    signal int_fullImage_cols  : UNSIGNED(31 downto 0) := (others => '0');
    signal int_emissions       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_grid_rows       : UNSIGNED(31 downto 0) := (others => '0');
    signal int_grid_cols       : UNSIGNED(31 downto 0) := (others => '0');
    signal int_targetGeometry_mem : UNSIGNED(63 downto 0) := (others => '0');
    signal int_compZoneRowStart : UNSIGNED(31 downto 0) := (others => '0');
    signal int_compZoneRowEnd  : UNSIGNED(31 downto 0) := (others => '0');
    signal int_compZoneColStart : UNSIGNED(31 downto 0) := (others => '0');
    signal int_compZoneColEnd  : UNSIGNED(31 downto 0) := (others => '0');
    signal int_moveCount_ap_vld : STD_LOGIC;
    signal int_moveCount       : UNSIGNED(31 downto 0) := (others => '0');


begin
-- ----------------------- Instantiation------------------


-- ----------------------- AXI WRITE ---------------------
    AWREADY_t <=  '1' when wstate = wridle else '0';
    AWREADY   <=  AWREADY_t;
    WREADY_t  <=  '1' when wstate = wrdata else '0';
    WREADY    <=  WREADY_t;
    BRESP     <=  "00";  -- OKAY
    BVALID    <=  '1' when wstate = wrresp else '0';
    wmask     <=  (31 downto 24 => WSTRB(3), 23 downto 16 => WSTRB(2), 15 downto 8 => WSTRB(1), 7 downto 0 => WSTRB(0));
    aw_hs     <=  AWVALID and AWREADY_t;
    w_hs      <=  WVALID and WREADY_t;

    -- write FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                wstate <= wrreset;
            elsif (ACLK_EN = '1') then
                wstate <= wnext;
            end if;
        end if;
    end process;

    process (wstate, AWVALID, WVALID, BREADY)
    begin
        case (wstate) is
        when wridle =>
            if (AWVALID = '1') then
                wnext <= wrdata;
            else
                wnext <= wridle;
            end if;
        when wrdata =>
            if (WVALID = '1') then
                wnext <= wrresp;
            else
                wnext <= wrdata;
            end if;
        when wrresp =>
            if (BREADY = '1') then
                wnext <= wridle;
            else
                wnext <= wrresp;
            end if;
        when others =>
            wnext <= wridle;
        end case;
    end process;

    waddr_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (aw_hs = '1') then
                    waddr <= UNSIGNED(AWADDR(ADDR_BITS-1 downto 2) & (1 downto 0 => '0'));
                end if;
            end if;
        end if;
    end process;

-- ----------------------- AXI READ ----------------------
    ARREADY_t <= '1' when (rstate = rdidle) else '0';
    ARREADY <= ARREADY_t;
    RDATA   <= STD_LOGIC_VECTOR(rdata_data);
    RRESP   <= "00";  -- OKAY
    RVALID_t  <= '1' when (rstate = rddata) else '0';
    RVALID    <= RVALID_t;
    ar_hs   <= ARVALID and ARREADY_t;
    raddr   <= UNSIGNED(ARADDR(ADDR_BITS-1 downto 0));

    -- read FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                rstate <= rdreset;
            elsif (ACLK_EN = '1') then
                rstate <= rnext;
            end if;
        end if;
    end process;

    process (rstate, ARVALID, RREADY, RVALID_t)
    begin
        case (rstate) is
        when rdidle =>
            if (ARVALID = '1') then
                rnext <= rddata;
            else
                rnext <= rdidle;
            end if;
        when rddata =>
            if (RREADY = '1' and RVALID_t = '1') then
                rnext <= rdidle;
            else
                rnext <= rddata;
            end if;
        when others =>
            rnext <= rdidle;
        end case;
    end process;

    rdata_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (ar_hs = '1') then
                    rdata_data <= (others => '0');
                    case (TO_INTEGER(raddr)) is
                    when ADDR_AP_CTRL =>
                        rdata_data(9) <= int_interrupt;
                        rdata_data(7) <= int_auto_restart;
                        rdata_data(3) <= int_ap_ready;
                        rdata_data(2) <= int_ap_idle;
                        rdata_data(1) <= int_task_ap_done;
                        rdata_data(0) <= int_ap_start;
                    when ADDR_GIE =>
                        rdata_data(0) <= int_gie;
                    when ADDR_IER =>
                        rdata_data(1 downto 0) <= int_ier;
                    when ADDR_ISR =>
                        rdata_data(1 downto 0) <= int_isr;
                    when ADDR_MODE_DATA_0 =>
                        rdata_data <= RESIZE(int_mode(7 downto 0), 32);
                    when ADDR_EMISSION_THRESHOLD_DATA_0 =>
                        rdata_data <= RESIZE(int_emission_threshold(31 downto 0), 32);
                    when ADDR_ATOMLOCATIONSSIZE_DATA_0 =>
                        rdata_data <= RESIZE(int_atomLocationsSize(31 downto 0), 32);
                    when ADDR_PROJSHAPE0_DATA_0 =>
                        rdata_data <= RESIZE(int_projShape0(31 downto 0), 32);
                    when ADDR_PROJSHAPE1_DATA_0 =>
                        rdata_data <= RESIZE(int_projShape1(31 downto 0), 32);
                    when ADDR_ATOMLOCATIONS_DATA_0 =>
                        rdata_data <= RESIZE(int_atomLocations(31 downto 0), 32);
                    when ADDR_ATOMLOCATIONS_DATA_1 =>
                        rdata_data <= RESIZE(int_atomLocations(63 downto 32), 32);
                    when ADDR_PSFSUPERSAMPLE_DATA_0 =>
                        rdata_data <= RESIZE(int_psfSupersample(31 downto 0), 32);
                    when ADDR_IMAGEPROJECTIONSIZE_DATA_0 =>
                        rdata_data <= RESIZE(int_imageProjectionSize(31 downto 0), 32);
                    when ADDR_IMAGEPROJS_LOCAL_DATA_0 =>
                        rdata_data <= RESIZE(int_imageProjs_local(31 downto 0), 32);
                    when ADDR_IMAGEPROJS_LOCAL_DATA_1 =>
                        rdata_data <= RESIZE(int_imageProjs_local(63 downto 32), 32);
                    when ADDR_IMAGEPROJS_DATA_0 =>
                        rdata_data <= RESIZE(int_imageProjs(31 downto 0), 32);
                    when ADDR_IMAGEPROJS_DATA_1 =>
                        rdata_data <= RESIZE(int_imageProjs(63 downto 32), 32);
                    when ADDR_IMAGEPROJS_LOCAL_SIZE_DATA_0 =>
                        rdata_data <= RESIZE(int_imageProjs_local_size(31 downto 0), 32);
                    when ADDR_IMAGEPROJS_LOCAL_SIZE_DATA_1 =>
                        rdata_data <= RESIZE(int_imageProjs_local_size(63 downto 32), 32);
                    when ADDR_FULLIMAGE_DATA_0 =>
                        rdata_data <= RESIZE(int_fullImage(31 downto 0), 32);
                    when ADDR_FULLIMAGE_DATA_1 =>
                        rdata_data <= RESIZE(int_fullImage(63 downto 32), 32);
                    when ADDR_FULLIMAGE_ROWS_DATA_0 =>
                        rdata_data <= RESIZE(int_fullImage_rows(31 downto 0), 32);
                    when ADDR_FULLIMAGE_COLS_DATA_0 =>
                        rdata_data <= RESIZE(int_fullImage_cols(31 downto 0), 32);
                    when ADDR_EMISSIONS_DATA_0 =>
                        rdata_data <= RESIZE(int_emissions(31 downto 0), 32);
                    when ADDR_EMISSIONS_DATA_1 =>
                        rdata_data <= RESIZE(int_emissions(63 downto 32), 32);
                    when ADDR_GRID_ROWS_DATA_0 =>
                        rdata_data <= RESIZE(int_grid_rows(31 downto 0), 32);
                    when ADDR_GRID_COLS_DATA_0 =>
                        rdata_data <= RESIZE(int_grid_cols(31 downto 0), 32);
                    when ADDR_TARGETGEOMETRY_MEM_DATA_0 =>
                        rdata_data <= RESIZE(int_targetGeometry_mem(31 downto 0), 32);
                    when ADDR_TARGETGEOMETRY_MEM_DATA_1 =>
                        rdata_data <= RESIZE(int_targetGeometry_mem(63 downto 32), 32);
                    when ADDR_COMPZONEROWSTART_DATA_0 =>
                        rdata_data <= RESIZE(int_compZoneRowStart(31 downto 0), 32);
                    when ADDR_COMPZONEROWEND_DATA_0 =>
                        rdata_data <= RESIZE(int_compZoneRowEnd(31 downto 0), 32);
                    when ADDR_COMPZONECOLSTART_DATA_0 =>
                        rdata_data <= RESIZE(int_compZoneColStart(31 downto 0), 32);
                    when ADDR_COMPZONECOLEND_DATA_0 =>
                        rdata_data <= RESIZE(int_compZoneColEnd(31 downto 0), 32);
                    when ADDR_MOVECOUNT_DATA_0 =>
                        rdata_data <= RESIZE(int_moveCount(31 downto 0), 32);
                    when ADDR_MOVECOUNT_CTRL =>
                        rdata_data(0) <= int_moveCount_ap_vld;
                    when others =>
                        NULL;
                    end case;
                end if;
            end if;
        end if;
    end process;

-- ----------------------- Register logic ----------------
    interrupt            <= int_interrupt;
    ap_start             <= int_ap_start;
    task_ap_done         <= (ap_done and not auto_restart_status) or auto_restart_done;
    task_ap_ready        <= ap_ready and not int_auto_restart;
    auto_restart_done    <= auto_restart_status and (ap_idle and not int_ap_idle);
    mode                 <= STD_LOGIC_VECTOR(int_mode);
    emission_threshold   <= STD_LOGIC_VECTOR(int_emission_threshold);
    atomLocationsSize    <= STD_LOGIC_VECTOR(int_atomLocationsSize);
    projShape0           <= STD_LOGIC_VECTOR(int_projShape0);
    projShape1           <= STD_LOGIC_VECTOR(int_projShape1);
    atomLocations        <= STD_LOGIC_VECTOR(int_atomLocations);
    psfSupersample       <= STD_LOGIC_VECTOR(int_psfSupersample);
    imageProjectionSize  <= STD_LOGIC_VECTOR(int_imageProjectionSize);
    imageProjs_local     <= STD_LOGIC_VECTOR(int_imageProjs_local);
    imageProjs           <= STD_LOGIC_VECTOR(int_imageProjs);
    imageProjs_local_size <= STD_LOGIC_VECTOR(int_imageProjs_local_size);
    fullImage            <= STD_LOGIC_VECTOR(int_fullImage);
    fullImage_rows       <= STD_LOGIC_VECTOR(int_fullImage_rows);
    fullImage_cols       <= STD_LOGIC_VECTOR(int_fullImage_cols);
    emissions            <= STD_LOGIC_VECTOR(int_emissions);
    grid_rows            <= STD_LOGIC_VECTOR(int_grid_rows);
    grid_cols            <= STD_LOGIC_VECTOR(int_grid_cols);
    targetGeometry_mem   <= STD_LOGIC_VECTOR(int_targetGeometry_mem);
    compZoneRowStart     <= STD_LOGIC_VECTOR(int_compZoneRowStart);
    compZoneRowEnd       <= STD_LOGIC_VECTOR(int_compZoneRowEnd);
    compZoneColStart     <= STD_LOGIC_VECTOR(int_compZoneColStart);
    compZoneColEnd       <= STD_LOGIC_VECTOR(int_compZoneColEnd);

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_interrupt <= '0';
            elsif (ACLK_EN = '1') then
                if (int_gie = '1' and (int_isr(0) or int_isr(1)) = '1') then
                    int_interrupt <= '1';
                else
                    int_interrupt <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_start <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1' and WDATA(0) = '1') then
                    int_ap_start <= '1';
                elsif (ap_ready = '1') then
                    int_ap_start <= int_auto_restart; -- clear on handshake/auto restart
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_done <= ap_done;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_task_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_done = '1') then
                    int_task_ap_done <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_task_ap_done <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_idle <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_idle <= ap_idle;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_ready <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_ready = '1') then
                    int_ap_ready <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_ap_ready <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_auto_restart <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1') then
                    int_auto_restart <= WDATA(7);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                auto_restart_status <= '0';
            elsif (ACLK_EN = '1') then
                if (int_auto_restart = '1') then
                    auto_restart_status <= '1';
                elsif (ap_idle = '1') then
                    auto_restart_status <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_gie <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_GIE and WSTRB(0) = '1') then
                    int_gie <= WDATA(0);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ier <= (others=>'0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IER and WSTRB(0) = '1') then
                    int_ier <= UNSIGNED(WDATA(1 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(0) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(0) = '1' and ap_done = '1') then
                    int_isr(0) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(0) <= int_isr(0) xor WDATA(0); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(1) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(1) = '1' and ap_ready = '1') then
                    int_isr(1) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(1) <= int_isr(1) xor WDATA(1); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_mode(7 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_MODE_DATA_0) then
                    int_mode(7 downto 0) <= (UNSIGNED(WDATA(7 downto 0)) and wmask(7 downto 0)) or ((not wmask(7 downto 0)) and int_mode(7 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_emission_threshold(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_EMISSION_THRESHOLD_DATA_0) then
                    int_emission_threshold(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_emission_threshold(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_atomLocationsSize(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_ATOMLOCATIONSSIZE_DATA_0) then
                    int_atomLocationsSize(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_atomLocationsSize(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_projShape0(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PROJSHAPE0_DATA_0) then
                    int_projShape0(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_projShape0(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_projShape1(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PROJSHAPE1_DATA_0) then
                    int_projShape1(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_projShape1(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_atomLocations(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_ATOMLOCATIONS_DATA_0) then
                    int_atomLocations(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_atomLocations(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_atomLocations(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_ATOMLOCATIONS_DATA_1) then
                    int_atomLocations(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_atomLocations(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_psfSupersample(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PSFSUPERSAMPLE_DATA_0) then
                    int_psfSupersample(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_psfSupersample(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_imageProjectionSize(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IMAGEPROJECTIONSIZE_DATA_0) then
                    int_imageProjectionSize(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_imageProjectionSize(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_imageProjs_local(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IMAGEPROJS_LOCAL_DATA_0) then
                    int_imageProjs_local(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_imageProjs_local(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_imageProjs_local(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IMAGEPROJS_LOCAL_DATA_1) then
                    int_imageProjs_local(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_imageProjs_local(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_imageProjs(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IMAGEPROJS_DATA_0) then
                    int_imageProjs(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_imageProjs(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_imageProjs(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IMAGEPROJS_DATA_1) then
                    int_imageProjs(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_imageProjs(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_imageProjs_local_size(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IMAGEPROJS_LOCAL_SIZE_DATA_0) then
                    int_imageProjs_local_size(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_imageProjs_local_size(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_imageProjs_local_size(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IMAGEPROJS_LOCAL_SIZE_DATA_1) then
                    int_imageProjs_local_size(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_imageProjs_local_size(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_fullImage(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_FULLIMAGE_DATA_0) then
                    int_fullImage(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_fullImage(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_fullImage(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_FULLIMAGE_DATA_1) then
                    int_fullImage(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_fullImage(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_fullImage_rows(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_FULLIMAGE_ROWS_DATA_0) then
                    int_fullImage_rows(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_fullImage_rows(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_fullImage_cols(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_FULLIMAGE_COLS_DATA_0) then
                    int_fullImage_cols(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_fullImage_cols(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_emissions(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_EMISSIONS_DATA_0) then
                    int_emissions(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_emissions(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_emissions(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_EMISSIONS_DATA_1) then
                    int_emissions(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_emissions(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_grid_rows(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_GRID_ROWS_DATA_0) then
                    int_grid_rows(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_grid_rows(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_grid_cols(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_GRID_COLS_DATA_0) then
                    int_grid_cols(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_grid_cols(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_targetGeometry_mem(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_TARGETGEOMETRY_MEM_DATA_0) then
                    int_targetGeometry_mem(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_targetGeometry_mem(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_targetGeometry_mem(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_TARGETGEOMETRY_MEM_DATA_1) then
                    int_targetGeometry_mem(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_targetGeometry_mem(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_compZoneRowStart(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_COMPZONEROWSTART_DATA_0) then
                    int_compZoneRowStart(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_compZoneRowStart(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_compZoneRowEnd(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_COMPZONEROWEND_DATA_0) then
                    int_compZoneRowEnd(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_compZoneRowEnd(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_compZoneColStart(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_COMPZONECOLSTART_DATA_0) then
                    int_compZoneColStart(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_compZoneColStart(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_compZoneColEnd(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_COMPZONECOLEND_DATA_0) then
                    int_compZoneColEnd(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_compZoneColEnd(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_moveCount <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (moveCount_ap_vld = '1') then
                    int_moveCount <= UNSIGNED(moveCount);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_moveCount_ap_vld <= '0';
            elsif (ACLK_EN = '1') then
                if (moveCount_ap_vld = '1') then
                    int_moveCount_ap_vld <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_MOVECOUNT_CTRL) then
                    int_moveCount_ap_vld <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;


-- ----------------------- Memory logic ------------------

end architecture behave;
